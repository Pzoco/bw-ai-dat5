#pragma once
namespace BWAPI
{
  /** Used for converting between TilePosition coordinates and Position coordinates. */
  #define TILE_SIZE      32
}
