Stormplugin by MasterOfChaos
Version 0.1.5
For patch 1.16.1

Features:
* Hide the progressbar in replays
  Press Ctrl+H to toggle it while viewing a replay
* Unshift hotkeys on AZERTY keyboards
  French and similar layouts are called AZERTY named after the first characters
  of the first line of these keyboards. These layouts have the strange property
  that if you press a number without shift you actually type some special character
  and you need to press shift to access numbers which includes unithotkeys.
  This setting is not to be used with american, german etc keyboard layouts.
* Press Ctrl+L to find out who is lagging.
  If you are the one who is lagging you will get a wrong result,
  just like you get a wrong result in the dropscreen if you disconnected.
  This uses the default starcraft lag/dropscreen. If nobody is lagging it will not show up.

Alphaversion - May still contain bugs
Like every 3rd partytool working together with Starcraft there is a small risk,
that blizzard decides to invalidate the users Accounts/CD-Keys or give you losses for won games.
Hooks Starcraft functions, so the risk is larger than with Chaosplugin.
USE AT YOUR OWN RISK!